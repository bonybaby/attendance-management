<?php

/* Teacher DASHBOARD
*Author:BONY
*/


include("header.php");?>

<div>
<img src="3.png"width="250px" height="150px" style="float:right;">
</div>
<div class="btd">
<form class="btf">

<button class="bt"><a href="attendancesheet.php">MARK ATTENDANCE</a></button><br><br>
<button class="bt"><a href="view_req.php">VIEW LEAVE REQUEST</a></button><br><br>
<button class="bt"><a href="division.php">ADD DIVISION</a></button><br><br>
<button class="bt"><a href="class.php">ADD CLASS</a></button><br><br>
<button class="bt"><a href="subject.php">ADD SUBJECT</a></button><br><br>
<button class="bt"><a href="batch.php">ADD BATCH</a></button><br><br>
<button class="bt"><a href="notiview.php">Notification</a></button><br><br>
</form>

</div>
<?php
include("footer.php");?>