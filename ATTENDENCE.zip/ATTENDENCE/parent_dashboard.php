<?php
/* PARENT DASHBOARD
*Author:ANIT
*/

include("header.php");?>

<div>
<img src="3.png"width="250px" height="150px" style="float:right;">
</div>
<div class="btd">
<form class="btf">
<button class="bt"><a href="attendance.php">VIEW ATTENDANCE</a></button><br><br>
<button class="bt"><a href="#">VIEW LEAVE</button><br><br>
<button class="bt"><a href="notiview.php">NOTIFICATION</button><br><br>
<button class="bt"><a href="messagebox.php">MESSAGEBOX</a></button><br><br>

</form>

</div>
<?php
include("footer.php");?>
