<?php
/*  CONTACT PAGE
  *Author:AMRITHA
*/
include("header.php");?>
<div class="t">
<h2>Address:</h2>
<p>Orisys Academy for Skill Development & Research
First Floor, Sumaj Complex,
Chavadimukku, Sreekaryam,
Trivandrum – 695017</p>

<h3>Phone:</h3> 04712737860

<h3>Email:</h3> contact@orisysacademy.com
</div>
<?php
include("footer.php");?>